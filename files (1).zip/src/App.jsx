import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import SummaryCards from "./components/SummaryCards";
import SpendingChart from "./components/SpendingChart";
import ExpensesDoughnut from "./components/ExpensesDoughnut";
import TransactionList from "./components/TransactionList";
import AddTransaction from "./components/AddTransaction";

/*
  App stores transactions in localStorage under "et_transactions".
  Beginner friendly: plain React (no TypeScript).
*/

const STORAGE_KEY = "et_transactions_v1";

export default function App() {
  const [transactions, setTransactions] = useState([]);

  // load from localStorage on mount
  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        setTransactions(JSON.parse(raw));
      } catch {
        setTransactions([]);
      }
    } else {
      // seed with example data
      const seed = [
        { id: 1, date: "2026-04-28", description: "Zomato Order", amount: -780, category: "Food & Dining" },
        { id: 2, date: "2026-04-27", description: "Salary", amount: 45000, category: "Income" },
        { id: 3, date: "2026-04-25", description: "Grocery", amount: -1210, category: "Shopping" },
        { id: 4, date: "2026-04-22", description: "Electricity Bill", amount: -1650, category: "Bills & Utilities" }
      ];
      setTransactions(seed);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (tx) => {
    const next = [...transactions, { ...tx, id: Date.now() }];
    setTransactions(next);
  };

  const deleteTransaction = (id) => {
    setTransactions(transactions.filter((t) => t.id !== id));
  };

  return (
    <div className="app">
      <Sidebar />
      <div className="content">
        <Header />
        <main>
          <SummaryCards transactions={transactions} />
          <section className="charts-row">
            <div className="chart-card">
              <SpendingChart transactions={transactions} />
            </div>
            <div className="chart-card">
              <ExpensesDoughnut transactions={transactions} />
            </div>
          </section>

          <section className="below-row">
            <div className="tx-panel">
              <TransactionList transactions={transactions} onDelete={deleteTransaction} />
            </div>
            <div className="add-panel">
              <AddTransaction onAdd={addTransaction} />
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}