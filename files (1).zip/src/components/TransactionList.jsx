import React from "react";

function formatCurrency(n) {
  return n.toLocaleString("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 0 });
}

export default function TransactionList({ transactions, onDelete }) {
  const list = transactions.slice().reverse();
  return (
    <div className="transactions-card">
      <div className="card-head">
        <h3>Recent Transactions</h3>
        <a className="view-all" href="#">View All →</a>
      </div>
      <table className="tx-table">
        <thead>
          <tr><th>Date</th><th>Description</th><th>Category</th><th>Type</th><th>Amount</th><th></th></tr>
        </thead>
        <tbody>
          {list.map(tx => (
            <tr key={tx.id}>
              <td>{tx.date}</td>
              <td>{tx.description}</td>
              <td><span className="chip">{tx.category}</span></td>
              <td>{Number(tx.amount) >= 0 ? <span className="type income">Income</span> : <span className="type expense">Expense</span>}</td>
              <td className={Number(tx.amount) >= 0 ? "amt income" : "amt expense"}>{formatCurrency(tx.amount)}</td>
              <td><button className="small-del" onClick={() => onDelete(tx.id)}>Delete</button></td>
            </tr>
          ))}
          {list.length === 0 && <tr><td colSpan="6" style={{textAlign:"center",padding:"12px"}}>No transactions yet</td></tr>}
        </tbody>
      </table>
    </div>
  );
}