import React, { useState } from "react";

export default function AddTransaction({ onAdd }) {
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Other");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));

  function submit(e) {
    e.preventDefault();
    if (!amount) return alert("Please enter an amount (use negative for expense)");
    const n = Number(amount);
    if (isNaN(n)) return alert("Amount must be a number");
    onAdd({ description: description || "—", amount: n, category, date });
    setDescription(""); setAmount(""); setCategory("Other"); setDate(new Date().toISOString().slice(0, 10));
  }

  return (
    <div className="add-card">
      <h3>Add Transaction</h3>
      <form onSubmit={submit}>
        <label>Description
          <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="e.g., Zomato order" />
        </label>

        <label>Amount
          <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Use negative for expense, e.g., -150" />
        </label>

        <label>Category
          <input value={category} onChange={(e) => setCategory(e.target.value)} />
        </label>

        <label>Date
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </label>

        <button className="save" type="submit">Save</button>
      </form>
    </div>
  );
}