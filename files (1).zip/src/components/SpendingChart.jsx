import React, { useMemo } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from "chart.js";
import { Line } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

export default function SpendingChart({ transactions }) {
  // build a simple daily totals series for the last 12 days
  const { labels, data } = useMemo(() => {
    const days = 12;
    const arrLabels = [];
    const arrData = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const label = `${d.getDate()}/${d.getMonth() + 1}`;
      arrLabels.push(label);
      const dayTotal = transactions
        .filter(t => {
          const td = new Date(t.date);
          return td.getDate() === d.getDate() && td.getMonth() === d.getMonth() && td.getFullYear() === d.getFullYear();
        })
        .reduce((s, t) => s + Number(t.amount), 0);
      arrData.push(Math.max(0, -dayTotal)); // show spending as positive on chart
    }
    return { labels: arrLabels, data: arrData };
  }, [transactions]);

  const chartData = {
    labels,
    datasets: [
      {
        label: "Spending",
        data,
        fill: true,
        backgroundColor: "rgba(124,58,237,0.12)",
        borderColor: "#7C3AED",
        tension: 0.35,
        pointRadius: 3,
        pointBackgroundColor: "#fff",
      },
    ],
  };

  const options = {
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: "#9aa0a6" }, grid: { display: false } },
      y: { ticks: { color: "#9aa0a6" }, grid: { color: "rgba(255,255,255,0.03)" } },
    },
    maintainAspectRatio: false,
  };

  return (
    <div style={{ height: 260 }}>
      <h3 className="chart-title">Spending Trend</h3>
      <Line data={chartData} options={options} />
    </div>
  );
}