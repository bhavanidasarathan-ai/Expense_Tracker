import React, { useMemo } from "react";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { Doughnut } from "react-chartjs-2";

ChartJS.register(ArcElement, Tooltip, Legend);

export default function ExpensesDoughnut({ transactions }) {
  const { labels, data, colors, total } = useMemo(() => {
    const map = {};
    transactions.forEach(t => {
      const cat = t.category || "Other";
      if (!map[cat]) map[cat] = 0;
      if (t.amount < 0) map[cat] += Math.abs(Number(t.amount));
    });
    const entries = Object.entries(map).sort((a, b) => b[1] - a[1]);
    const palette = ["#7C3AED", "#FF6B6B", "#4D96FF", "#F39C12", "#16A085", "#FFB86B"];
    return {
      labels: entries.map(e => e[0]),
      data: entries.map(e => e[1]),
      colors: entries.map((_, i) => palette[i % palette.length]),
      total: entries.reduce((s, e) => s + e[1], 0),
    };
  }, [transactions]);

  const chartData = {
    labels,
    datasets: [
      {
        data,
        backgroundColor: colors,
        hoverOffset: 8,
      },
    ],
  };

  const options = {
    plugins: { legend: { position: "right", labels: { color: "#9aa0a6" } } },
    maintainAspectRatio: false,
  };

  return (
    <div style={{ height: 260 }}>
      <h3 className="chart-title">Expenses by Category</h3>
      <div className="doughnut-wrap">
        <Doughnut data={chartData} options={options} />
        <div className="doughnut-total">
          <div className="small">Total</div>
          <div className="big">₹{Number(total).toLocaleString()}</div>
        </div>
      </div>
    </div>
  );
}