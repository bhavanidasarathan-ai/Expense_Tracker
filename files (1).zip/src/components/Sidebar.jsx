import React from "react";

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="logo">💰</div>
        <div className="brand-text">Fast Budget</div>
      </div>

      <nav className="nav">
        <ul>
          <li className="active">Dashboard</li>
          <li>Transactions</li>
          <li>Budgets</li>
          <li>Reports</li>
          <li>Goals</li>
          <li>Settings</li>
        </ul>
      </nav>

      <div className="promo">
        <div className="promo-title">Go Premium 🚀</div>
        <div className="promo-desc">Unlock analytics, unlimited categories and export</div>
        <button className="promo-btn">Upgrade Now</button>
      </div>
    </aside>
  );
}