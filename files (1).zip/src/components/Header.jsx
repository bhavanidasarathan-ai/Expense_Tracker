import React from "react";

export default function Header() {
  return (
    <header className="header-row">
      <h1 className="page-title">Dashboard</h1>
      <div className="header-actions">
        <input className="search" placeholder="Search transactions, categories..." />
        <button className="btn ghost">Export</button>
        <button className="btn primary">+ Add</button>
      </div>
    </header>
  );
}