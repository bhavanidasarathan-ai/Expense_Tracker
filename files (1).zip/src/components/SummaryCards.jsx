import React from "react";

function formatCurrency(n) {
  return n.toLocaleString("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 2 });
}

export default function SummaryCards({ transactions }) {
  const total = transactions.reduce((s, t) => s + Number(t.amount), 0);
  const income = transactions.filter(t => t.amount > 0).reduce((s, t) => s + Number(t.amount), 0);
  const expenses = transactions.filter(t => t.amount < 0).reduce((s, t) => s + Number(t.amount), 0);
  const savings = total;

  return (
    <section className="summary-cards">
      <div className="card">
        <div className="card-title">Total Balance</div>
        <div className="card-value">{formatCurrency(total)}</div>
        <div className="card-foot">▲ 8.5% from last month</div>
      </div>

      <div className="card">
        <div className="card-title">Total Income</div>
        <div className="card-value">{formatCurrency(income)}</div>
        <div className="card-foot">▲ 12.3% from last month</div>
      </div>

      <div className="card">
        <div className="card-title">Total Expenses</div>
        <div className="card-value">{formatCurrency(Math.abs(expenses))}</div>
        <div className="card-foot">▼ 5.7% from last month</div>
      </div>

      <div className="card">
        <div className="card-title">This Month Savings</div>
        <div className="card-value">{formatCurrency(savings)}</div>
        <div className="card-foot">▲ 15.2% from last month</div>
      </div>
    </section>
  );
}